package ms28.az;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ms28Application {

    public static void main(String[] args) {
        SpringApplication.run(Ms28Application.class, args);
    }

}
