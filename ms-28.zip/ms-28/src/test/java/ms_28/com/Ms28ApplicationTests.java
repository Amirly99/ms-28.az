package ms_28.com;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ms28ApplicationTests {

    @Test
    void contextLoads() {
    }

}
