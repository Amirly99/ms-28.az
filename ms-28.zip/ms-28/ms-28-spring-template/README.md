## change.my.name

### Table of Contents

- [Run](#Run)
- [Tech stack](#Tech-stack)

### Run

```shell script
$ java -jar change.my.name.jar
```

### Tech stack

1. Spring Boot
2. Java 17